Rename this debug library without the "_debug" suffix and replace (maybe backup the original first) the library.
For example, to replace the x64 ENet Library with the Debug version, you'd first backup/move "libenet.so", then extract and rename "libenet_debug.so" to "libenet.so".

If you have trouble, file a GitHub support ticket at https://github.com/SoftwareGuy/Ignorance.

- Coburn
